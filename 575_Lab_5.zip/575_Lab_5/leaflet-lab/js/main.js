/* Map of GeoJSON data from Lab4_data.geojson */

//function to instantiate the Leaflet map
function createMap(){
    //create the map
    var map = L.map('mapid', {
        center: [38.6999, -97.6642],
        zoom: 3.5
    });

    //add OSM base tilelayer
    L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
    }).addTo(map);

    //call getData function
    getData(map);
};


//Add circle markers for point features to the map
function createPropSymbols(data,map){
	
	var attribute = "YR_2010";
	
    //create marker options
    var options = {
        radius: 8,
        fillColor: "#228B22",
        color: "#000",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8
    };


	//calculate the radius of each proportional symbol
	function calcPropRadius(attValue) {
		//scale factor to adjust symbol size evenly
		var scaleFactor = .01;
		//area based on attribute value and scale factor
		var area = attValue * scaleFactor;
		//radius calculated based on area
		var radius = Math.sqrt(area/Math.PI);

		return radius;
	};
	
	//create a Leaflet GeoJSON layer and add it to the map
	L.geoJson(data, {
		pointToLayer: function (feature, latlng) {
			//Step 5: For each feature, determine its value for the selected attribute
			var attValue = Number(feature.properties[attribute]);

			//examine the attribute value to check that it is correct
			console.log(feature.properties, attribute);
			
			//Give each feature's circle marker a radius based on its attribute value
			options.radius = calcPropRadius(attValue);
			
			//create circle markers
			var layer = L.circleMarker(latlng, options);
			
			//build popup content string starting with city...Example 2.1 line 24
			var popupContent = "<p><b>City:</b> " + feature.properties.City + "</p>";

			//add formatted attribute to popup content string
			var year = attribute.split("_")[1];
			popupContent += "<p><b>Average Income in " + year + ":</b> " + feature.properties[attribute] + " Dollars</p>";
			
			//bind the popup to the circle marker
			layer.bindPopup(popupContent, {
				offset: new L.Point(0,-options.radius) 
			});
			
			//event listeners to open popup on hover
			layer.on({
				mouseover: function(){
					this.openPopup();
				},
				mouseout: function(){
					this.closePopup();
				}
			});
			
			//return the circle marker to the L.geoJson pointToLayer option
			return layer;
		}	
    }).addTo(map);
};


//Import GeoJSON data
function getData(map){
    //load the data
    $.ajax("data/Lab4_data.geojson", {
        dataType: "json",
        success: function(response){
            //call function to create proportional symbols
            createPropSymbols(response, map);
        }
    });
};

$(document).ready(createMap);